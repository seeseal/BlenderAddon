bl_info = {
    "name": "Auto_EXR_Pass_Setup",
    "blender": (4, 0, 2),
    "category": "Render",
    "version": (1, 0, 6),
    "author": "SeeSeal & Bhavish",
    "location": "Render > Auto_EXR_Pass_Setup",
    "wiki_url": "https://github.com/seeseal/BlenderAddons/wiki",
    "tracker_url": "https://github.com/seeseal/BlenderAddons/issues",
    "support": "COMMUNITY",
    "description": "Automatically sets up EXR passes for rendering.",
}

import bpy
import os
import urllib.request
import json

addon_name = bl_info['name']
github_repo = "seeseal/BlenderAddons"
releases_url = f"https://api.github.com/repos/{github_repo}/releases/latest"

def check_for_updates():
    try:
        with urllib.request.urlopen(releases_url) as url:
            data = json.loads(url.read().decode())
            latest_version = data['tag_name'].strip('v')
            return latest_version
    except Exception as e:
        print(f"Error checking for updates: {e}")
        return None

def notify_update_available(latest_version):
    message = f"A new version ({latest_version}) of {addon_name} is available! Download from GitHub."
    bpy.ops.ui.popup_notification(message=message, title="Addon Update Available", icon='INFO')

def auto_exr_pass_setup():
    # Get the current scene
    scene = bpy.context.scene

    # Ensure nodes are used in the compositor
    scene.use_nodes = True
    tree = scene.node_tree

    # Clear existing nodes
    for node in tree.nodes:
        tree.nodes.remove(node)

    # Denoising Data Pass Enable
    bpy.context.view_layer.cycles.denoising_store_passes = True

    # Enable Required Passes for the view layer
    view_layer = bpy.context.scene.view_layers["ViewLayer"]
    view_layer.use_pass_combined = True
    view_layer.use_pass_mist = True
    view_layer.use_pass_uv = True
    view_layer.use_pass_position = True
    view_layer.use_pass_emit = True
    view_layer.use_pass_environment = True
    view_layer.use_pass_ambient_occlusion = True
    view_layer.use_pass_cryptomatte_material = True
    view_layer.use_pass_cryptomatte_object = True

    # Define passes and their respective indices in the RenderLayers outputs
    passes = {
        'Image': 'Image',
        'Alpha': 'Alpha',
        'Mist': 'Mist',
        'Position': 'Position',
        'UV': 'UV',
        'Emit': 'Emit',
        'Env': 'Env',
        'AO': 'AO',
        'CryptoObject00': 'CryptoObject00',
        'CryptoObject01': 'CryptoObject01',
        'CryptoObject02': 'CryptoObject02',
        'CryptoMaterial00': 'CryptoMaterial00',
        'CryptoMaterial01': 'CryptoMaterial01',
        'CryptoMaterial02': 'CryptoMaterial02',
    }

    # Add Render Layers node
    render_layers = tree.nodes.new('CompositorNodeRLayers')
    render_layers.location = (-200, 0)

    # Add File Output node
    file_output = tree.nodes.new('CompositorNodeOutputFile')
    file_output.location = (400, 0)
    file_output.format.file_format = 'OPEN_EXR_MULTILAYER'
    file_output.format.exr_codec = 'DWAA'
    file_output.file_slots.clear()  # Clear existing file slots

    # Denoise nodes setup
    denoise_nodes = {}
    denoise_count = 0
    max_denoise_nodes = 18

    # Connect passes to File Output node
    for output_name in passes:
        if output_name in ['Denoising Normal', 'Denoising Albedo', 'Denoising Depth']:
            continue

        if output_name.startswith('Crypto'):
            # Skip denoising for crypto passes
            if output_name not in file_output.file_slots:
                file_output.file_slots.new(name=output_name)
            tree.links.new(render_layers.outputs[output_name], file_output.inputs[output_name])
            continue

        # If denoise count hasn't reached maximum, add denoise node
        if denoise_count < max_denoise_nodes:
            denoise_node = tree.nodes.new('CompositorNodeDenoise')
            denoise_node.location = (100, denoise_count * -150)

            # Connect render layer pass to denoise node
            tree.links.new(render_layers.outputs[output_name], denoise_node.inputs['Image'])

            # Connect albedo and normal to denoise node if they exist
            if 'Denoising Albedo' in render_layers.outputs and 'Denoising Normal' in render_layers.outputs:
                tree.links.new(render_layers.outputs['Denoising Albedo'], denoise_node.inputs['Albedo'])
                tree.links.new(render_layers.outputs['Denoising Normal'], denoise_node.inputs['Normal'])

            # Connect denoise node to file output
            if output_name not in file_output.file_slots:
                file_output.file_slots.new(name=output_name)
            tree.links.new(denoise_node.outputs['Image'], file_output.inputs[output_name])

            denoise_nodes[output_name] = denoise_node
            denoise_count += 1
        else:
            # If denoise count has reached maximum, connect directly to file output
            if output_name not in file_output.file_slots:
                file_output.file_slots.new(name=output_name)
            tree.links.new(render_layers.outputs[output_name], file_output.inputs[output_name])

    # Update node locations for readability
    render_layers.location = (-200, 0)
    file_output.location = (400, 0)

class AutoEXRPassSetupOperator(bpy.types.Operator):
    bl_idname = "node.auto_exr_pass_setup"
    bl_label = "Auto EXR Pass Setup"

    def execute(self, context):
        render_filepath_set(context.scene)
        auto_exr_pass_setup()
        return {'FINISHED'}
    
class AutoEXRPassSetupPanel(bpy.types.Panel):
    bl_idname = "NODE_PT_auto_exr_pass_setup"
    bl_label = "Auto EXR Pass Setup"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Tool'

    def draw(self, context):
        layout = self.layout
        layout.operator("node.auto_exr_pass_setup")


def register():
    bpy.utils.register_class(AutoEXRPassSetupOperator)
    bpy.utils.register_class(AutoEXRPassSetupPanel)
    bpy.utils.register_class(AutoEXRPassSetupErrorOperator)

    # Check for updates on addon registration
    latest_version_str = check_for_updates()
    if latest_version_str:
        latest_version = tuple(map(int, latest_version_str.split('.')))
        addon_version = bl_info['version']
        if latest_version > addon_version:
            notify_update_available(latest_version)
            print(f"Updated version {latest_version} is available. Please download from {bl_info['tracker_url']}.")

def unregister():
    bpy.utils.unregister_class(AutoEXRPassSetupOperator)
    bpy.utils.unregister_class(AutoEXRPassSetupPanel)
    bpy.utils.unregister_class(AutoEXRPassSetupErrorOperator)

if __name__ == "__main__":
    register()