bl_info = {
    "name": "Auto EXR Pass Setup",
    "blender": (2, 80, 0),
    "category": "Render",
    "version": (1, 0, 3),
    "author": "SeeSeal & Bhavish",
    "location": "Render > Auto EXR Pass Setup",
    "wiki_url": "https://github.com/seeseal/BlenderAddons/wiki",
    "tracker_url": "https://github.com/seeseal/BlenderAddons/issues",
    "support": "COMMUNITY",
    "description": "Automatically sets up EXR passes for rendering.",
}

import bpy
import os
import urllib.request
import json

addon_name = bl_info['name']
github_repo = "seeseal/BlenderAddons"
releases_url = f"https://api.github.com/repos/{github_repo}/releases/latest"

def check_for_updates():
    try:
        with urllib.request.urlopen(releases_url) as url:
            data = json.loads(url.read().decode())
            latest_version = data['tag_name'].strip('v')
            return latest_version
    except Exception as e:
        print(f"Error checking for updates: {e}")
        return None

def notify_update_available(latest_version):
    message = f"A new version ({latest_version}) of {addon_name} is available! Download from GitHub."
    bpy.ops.ui.popup_notification(message=message, title="Addon Update Available", icon='INFO')

def render_filepath_set(scene):
    try:
        blend_file_dir = bpy.path.abspath('//')
        renders_folder = os.path.join(blend_file_dir, "Renders")
        os.makedirs(renders_folder, exist_ok=True)

        blend_file_name = bpy.path.display_name_from_filepath(bpy.data.filepath)
        blend_file_path = os.path.join(renders_folder, blend_file_name)
        os.makedirs(blend_file_path, exist_ok=True)

        scene_name = scene.name
        scene_path = os.path.join(blend_file_path, scene_name)
        os.makedirs(scene_path, exist_ok=True)

        # Set render output filepath to scene directory with "####" for frame numbering
        scene.render.filepath = os.path.join(scene_path, "####")

        # Set render output file format to EXR
        scene.render.image_settings.file_format = 'OPEN_EXR_MULTILAYER'
        scene.render.image_settings.exr_codec = 'DWAA'
    except PermissionError:
        bpy.ops.render.auto_exr_pass_setup_error('INVOKE_DEFAULT')

class AutoEXRPassSetupErrorOperator(bpy.types.Operator):
    bl_idname = "render.auto_exr_pass_setup_error"
    bl_label = "Auto EXR Pass Setup Error"

    def execute(self, context):
        self.report({'ERROR'}, "Access is denied: Please save the file in a different location.")
        return {'FINISHED'}

    def invoke(self, context, event):
        self.execute(context)
        return {'FINISHED'}

def auto_exr_pass_setup():
    # Get the current scene
    scene = bpy.context.scene

    # Ensure nodes are used in the compositor
    scene.use_nodes = True
    tree = scene.node_tree

    # Clear existing nodes
    tree.nodes.clear()

    # Enable Denoising Data Pass
    bpy.context.view_layer.cycles.denoising_store_passes = True

    # Enable required passes for the view layer
    view_layer = scene.view_layers["ViewLayer"]
    view_layer.use_pass_combined = True
    view_layer.use_pass_mist = True
    view_layer.use_pass_uv = True
    view_layer.use_pass_position = True
    view_layer.use_pass_emit = True
    view_layer.use_pass_environment = True
    view_layer.use_pass_ambient_occlusion = True
    view_layer.use_pass_cryptomatte_material = True
    view_layer.use_pass_cryptomatte_object = True

    # Define passes and their respective indices in the RenderLayers outputs
    passes = {
        'Image': 'Image',
        'Alpha': 'Alpha',
        'Mist': 'Mist',
        'Position': 'Position',
        'UV': 'UV',
        'Emit': 'Emit',
        'Env': 'Env',
        'AO': 'AO',
        'CryptoObject00': 'CryptoObject00',
        'CryptoObject01': 'CryptoObject01',
        'CryptoObject02': 'CryptoObject02',
        'CryptoMaterial00': 'CryptoMaterial00',
        'CryptoMaterial01': 'CryptoMaterial01',
        'CryptoMaterial02': 'CryptoMaterial02',
    }

    # Add Render Layers node
    render_layers = tree.nodes.new('CompositorNodeRLayers')
    render_layers.location = (-200, 0)

    # Add File Output node for EXR
    file_output_exr = tree.nodes.new('CompositorNodeOutputFile')
    file_output_exr.location = (400, 0)
    file_output_exr.format.file_format = 'OPEN_EXR_MULTILAYER'
    file_output_exr.format.exr_codec = 'DWAA'
    file_output_exr.file_slots.clear()  # Clear existing file slots

    # Add File Output node for PNG preview
    file_output_png = tree.nodes.new('CompositorNodeOutputFile')
    file_output_png.location = (400, -400)
    file_output_png.format.file_format = 'PNG'
    file_output_png.file_slots.clear()  # Clear existing file slots
    file_output_png.base_path = os.path.join(scene.render.filepath, "Preview")  # Ensure it saves in the preview directory
    file_output_png.file_slots.new(name="Preview")

    # Connect Render Layers Image output to PNG File Output node for preview
    tree.links.new(render_layers.outputs['Image'], file_output_png.inputs['Preview'])

    # Denoise nodes setup
    denoise_nodes = {}
    denoise_count = 0
    max_denoise_nodes = 18

    # Connect passes to EXR File Output node
    for output_name in passes:
        if output_name in ['Denoising Normal', 'Denoising Albedo', 'Denoising Depth']:
            continue

        if output_name.startswith('Crypto'):
            # Skip denoising for crypto passes
            if output_name not in file_output_exr.file_slots:
                file_output_exr.file_slots.new(name=output_name)
            tree.links.new(render_layers.outputs[output_name], file_output_exr.inputs[output_name])
            continue

        # If denoise count hasn't reached maximum, add denoise node
        if denoise_count < max_denoise_nodes:
            denoise_node = tree.nodes.new('CompositorNodeDenoise')
            denoise_node.location = (100, denoise_count * -150)

            # Connect render layer pass to denoise node
            tree.links.new(render_layers.outputs[output_name], denoise_node.inputs['Image'])

            # Connect albedo and normal to denoise node if they exist
            if 'Denoising Albedo' in render_layers.outputs and 'Denoising Normal' in render_layers.outputs:
                tree.links.new(render_layers.outputs['Denoising Albedo'], denoise_node.inputs['Albedo'])
                tree.links.new(render_layers.outputs['Denoising Normal'], denoise_node.inputs['Normal'])

            # Connect denoise node to EXR file output
            if output_name not in file_output_exr.file_slots:
                file_output_exr.file_slots.new(name=output_name)
            tree.links.new(denoise_node.outputs['Image'], file_output_exr.inputs[output_name])

            denoise_nodes[output_name] = denoise_node
            denoise_count += 1
        else:
            # If denoise count has reached maximum, connect directly to EXR file output
            if output_name not in file_output_exr.file_slots:
                file_output_exr.file_slots.new(name=output_name)
            tree.links.new(render_layers.outputs[output_name], file_output_exr.inputs[output_name])

    # Update node locations for readability
    render_layers.location = (-200, 0)
    file_output_exr.location = (400, 0)
    file_output_png.location = (400, -400)

class AutoEXRPassSetupOperator(bpy.types.Operator):
    bl_idname = "node.auto_exr_pass_setup"
    bl_label = "Auto EXR Pass Setup"

    def execute(self, context):
        render_filepath_set(context.scene)
        auto_exr_pass_setup()
        return {'FINISHED'}

class AutoEXRPassSetupPanel(bpy.types.Panel):
    bl_idname = "NODE_PT_auto_exr_pass_setup"
    bl_label = "Auto EXR Pass Setup"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Tool'

    def draw(self, context):
        layout = self.layout
        layout.operator("node.auto_exr_pass_setup")

def register():
    bpy.utils.register_class(AutoEXRPassSetupOperator)
    bpy.utils.register_class(AutoEXRPassSetupPanel)
    bpy.utils.register_class(AutoEXRPassSetupErrorOperator)

    # Check for updates on addon registration
    latest_version = check_for_updates()
    if latest_version and latest_version > bl_info['version']:
        notify_update_available(latest_version)

def unregister():
    bpy.utils.unregister_class(AutoEXRPassSetupOperator)
    bpy.utils.unregister_class(AutoEXRPassSetupPanel)
    bpy.utils.unregister_class(AutoEXRPassSetupErrorOperator)

if __name__ == "__main__":
    register()
